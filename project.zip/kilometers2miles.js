//input
let kilometers = 56;
//processing
miles = kilometers * 0.621371
//output
console.log(`${kilometers} is ${miles} miles`)